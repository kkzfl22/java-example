package com.liujun.depend.service;

/**
 * @author liujun
 * @version 0.0.1
 */
public interface StartInterface {

  /**
   * 启动服务
   *
   * @return
   */
  String start();
}
